Windows 10/11: Extract the ZIP, then double-click HMI-Windows.bat.
START = green lamp ON. STOP = gray lamp OFF.
Runs a native Windows Forms window using built-in Windows PowerShell.
No browser, internet, or installation needed. This is a .bat launcher, not an .exe.
Simulation only; does not control real equipment.
