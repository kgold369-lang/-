HMI Launcher v2 - Windows 10/11

Extract ALL files before running HMI-Windows.bat.
Keep HMI-Windows.bat and HMI-Windows.ps1 in the same folder.
START: green lamp ON. STOP: gray lamp OFF.
The console now stays open after errors. Share the displayed error if startup fails.
Uses Windows PowerShell and Windows Forms; no browser or installation needed.
Simulation only. This is not an EXE and is not connected to equipment.
